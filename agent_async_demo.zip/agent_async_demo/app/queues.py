from __future__ import annotations

from redis import Redis
from rq import Queue

from app.action_registry import ACTION_REGISTRY
from app.schemas import ActionType
from app.settings import settings


# RQ funciona melhor com decode_responses=False.
rq_redis = Redis.from_url(settings.redis_url, decode_responses=False)

agent_queue = Queue("agent", connection=rq_redis)
operation_queues = {
    "anexos": Queue("anexos", connection=rq_redis),
    "bec": Queue("bec", connection=rq_redis),
    "legibilidade": Queue("legibilidade", connection=rq_redis),
    "dossie": Queue("dossie", connection=rq_redis),
}


def enqueue_agent_planner(process_id: str, trigger: str = "manual") -> str:
    from app.jobs import run_agent_planner_job

    job = agent_queue.enqueue(
        run_agent_planner_job,
        process_id,
        trigger,
        job_timeout=180,
    )
    return job.id


def enqueue_operation(operation_id: str, action_type: ActionType) -> str:
    from app.jobs import execute_operation_job

    definition = ACTION_REGISTRY[action_type]
    queue = operation_queues[definition.queue_name]

    job = queue.enqueue(
        execute_operation_job,
        operation_id,
        job_timeout=180,
    )
    return job.id
