from __future__ import annotations

from dataclasses import dataclass

from app.schemas import ActionType, Operation, ProcessState


@dataclass(frozen=True)
class ActionDefinition:
    action_type: ActionType
    queue_name: str
    description: str
    requires_completed: tuple[ActionType, ...] = ()


ACTION_REGISTRY: dict[ActionType, ActionDefinition] = {
    "processador_anexos": ActionDefinition(
        action_type="processador_anexos",
        queue_name="anexos",
        description="Processa anexos e extrai dados iniciais.",
    ),
    "consulta_bec": ActionDefinition(
        action_type="consulta_bec",
        queue_name="bec",
        description="Consulta BEC usando dados extraídos dos anexos.",
        requires_completed=("processador_anexos",),
    ),
    "consulta_legibilidade": ActionDefinition(
        action_type="consulta_legibilidade",
        queue_name="legibilidade",
        description="Consulta legibilidade após a consulta BEC.",
        requires_completed=("consulta_bec",),
    ),
    "registra_dossie": ActionDefinition(
        action_type="registra_dossie",
        queue_name="dossie",
        description="Registra o dossiê final após todas as consultas obrigatórias.",
        requires_completed=("consulta_bec", "consulta_legibilidade"),
    ),
}


def get_available_actions(process: ProcessState, operations: list[Operation]) -> list[ActionType]:
    completed = {op.action_type for op in operations if op.status == "completed"}
    in_progress = {op.action_type for op in operations if op.status in {"scheduled", "running"}}

    available: list[ActionType] = []

    for action_type, definition in ACTION_REGISTRY.items():
        already_done = action_type in completed
        already_running = action_type in in_progress
        requirements_ok = all(required in completed for required in definition.requires_completed)

        if not already_done and not already_running and requirements_ok:
            available.append(action_type)

    return available
