from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any

from app.schemas import ActionType


def call_fake_mcp_service(action_type: ActionType, process_id: str) -> dict[str, Any]:
    """
    Aqui você substituiria pelo client MCP real.

    Neste projeto demo, cada serviço apenas dorme por alguns segundos
    e retorna um resultado fake.
    """
    time.sleep(2)

    now = datetime.now(timezone.utc).isoformat()

    if action_type == "processador_anexos":
        return {
            "service": "mcp-processador-anexos",
            "processed_at": now,
            "message": "Anexos processados com sucesso.",
            "extracted_fields": {
                "bec_number": "BEC-123456",
                "has_documents": True,
            },
        }

    if action_type == "consulta_bec":
        return {
            "service": "mcp-consulta-bec",
            "processed_at": now,
            "message": "Consulta BEC concluída.",
            "bec_status": "ok",
        }

    if action_type == "consulta_legibilidade":
        return {
            "service": "mcp-consulta-legibilidade",
            "processed_at": now,
            "message": "Consulta de legibilidade concluída.",
            "legibilidade": "aprovada",
        }

    if action_type == "registra_dossie":
        return {
            "service": "mcp-registra-dossie",
            "processed_at": now,
            "message": "Dossiê registrado com sucesso.",
            "dossie_id": f"DOS-{process_id[-6:].upper()}",
        }

    raise ValueError(f"Ação não suportada: {action_type}")
