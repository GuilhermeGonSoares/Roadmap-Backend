from __future__ import annotations

from app.agent import run_pydantic_agent
from app.fake_mcp_services import call_fake_mcp_service
from app.local_demo_agent import run_local_demo_agent
from app.queues import enqueue_agent_planner
from app.scheduler import scheduler
from app.schemas import AgentDeps
from app.settings import settings
from app.store import store


def run_agent_planner_job(process_id: str, trigger: str = "manual") -> None:
    """
    Job que representa uma rodada de decisão do agente.

    Ele não executa os processamentos. Ele só chama o agente, e o agente chama
    uma tool que agenda a próxima operação.
    """
    process = store.get_process(process_id)

    if process.status in {"finished", "failed", "needs_human_review"}:
        return

    process = store.increment_agent_iteration(process_id)

    if process.agent_iterations > settings.max_agent_iterations:
        process.status = "needs_human_review"
        store.save_process(process)
        store.append_decision(
            process_id,
            {
                "status": "needs_human_review",
                "reason": "Limite de iterações do agente atingido.",
            },
        )
        return

    deps = AgentDeps(process_id=process_id, store=store, scheduler=scheduler)

    if settings.use_local_demo_agent:
        decision = run_local_demo_agent(process_id=process_id, deps=deps)
    else:
        decision = run_pydantic_agent(process_id=process_id, trigger=trigger, deps=deps)

    store.append_decision(process_id, decision.model_dump())

    if decision.status == "finished":
        store.set_process_status(process_id, "finished")
        return

    if decision.status == "needs_human_review":
        store.set_process_status(process_id, "needs_human_review")
        return

    if decision.status == "failed":
        store.set_process_status(process_id, "failed")
        return

    # Se status == scheduled_operation, a tool já agendou a operação e o processo
    # ficou em waiting_operation. O worker vai reativar o agente quando terminar.


def execute_operation_job(operation_id: str) -> None:
    """
    Job executor de operação.

    Em produção, aqui entraria o client MCP real. Neste demo, chamamos um fake MCP
    com sleep + resultado estático.
    """
    operation = store.get_operation(operation_id)
    store.set_process_status(operation.process_id, "running_operation")
    store.update_operation_status(operation_id, "running")

    try:
        result = call_fake_mcp_service(
            action_type=operation.action_type,
            process_id=operation.process_id,
        )
        store.complete_operation(operation_id, result)
        enqueue_agent_planner(
            process_id=operation.process_id,
            trigger=f"operation_completed:{operation.action_type}",
        )
    except Exception as exc:
        store.fail_operation(operation_id, str(exc))
        enqueue_agent_planner(
            process_id=operation.process_id,
            trigger=f"operation_failed:{operation.action_type}",
        )
