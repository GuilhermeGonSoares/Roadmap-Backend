from __future__ import annotations

import json
import uuid
from typing import Any

from redis import Redis

from app.schemas import ActionType, Operation, OperationStatus, ProcessState, ProcessStatus
from app.settings import settings


def build_store_redis() -> Redis:
    return Redis.from_url(settings.redis_url, decode_responses=True)


class RedisStore:
    def __init__(self, redis_client: Redis | None = None):
        self.redis = redis_client or build_store_redis()

    def create_process(self, prompt: str) -> ProcessState:
        process = ProcessState(process_id=f"proc_{uuid.uuid4().hex[:12]}", prompt=prompt)
        self.save_process(process)
        return process

    def get_process(self, process_id: str) -> ProcessState:
        raw = self.redis.get(self._process_key(process_id))
        if raw is None:
            raise KeyError(f"Processo {process_id} não encontrado")
        return ProcessState.model_validate_json(raw)

    def save_process(self, process: ProcessState) -> None:
        self.redis.set(self._process_key(process.process_id), process.model_dump_json())

    def set_process_status(self, process_id: str, status: ProcessStatus) -> ProcessState:
        process = self.get_process(process_id)
        process.status = status
        self.save_process(process)
        return process

    def increment_agent_iteration(self, process_id: str) -> ProcessState:
        process = self.get_process(process_id)
        process.agent_iterations += 1
        process.status = "planning"
        self.save_process(process)
        return process

    def append_decision(self, process_id: str, decision: dict[str, Any]) -> None:
        process = self.get_process(process_id)
        process.decisions.append(decision)
        self.save_process(process)

    def create_operation(self, process_id: str, action_type: ActionType, reason: str) -> Operation:
        operation = Operation(
            operation_id=f"op_{uuid.uuid4().hex[:12]}",
            process_id=process_id,
            action_type=action_type,
            reason=reason,
        )
        self.save_operation(operation)

        process = self.get_process(process_id)
        process.operations.append(operation.operation_id)
        process.status = "waiting_operation"
        self.save_process(process)

        return operation

    def get_operation(self, operation_id: str) -> Operation:
        raw = self.redis.get(self._operation_key(operation_id))
        if raw is None:
            raise KeyError(f"Operação {operation_id} não encontrada")
        return Operation.model_validate_json(raw)

    def save_operation(self, operation: Operation) -> None:
        self.redis.set(self._operation_key(operation.operation_id), operation.model_dump_json())

    def update_operation_status(
        self,
        operation_id: str,
        status: OperationStatus,
        result: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> Operation:
        operation = self.get_operation(operation_id)
        operation.status = status
        operation.result = result
        operation.error = error
        self.save_operation(operation)
        return operation

    def complete_operation(self, operation_id: str, result: dict[str, Any]) -> None:
        operation = self.update_operation_status(operation_id, status="completed", result=result)
        process = self.get_process(operation.process_id)
        process.results[operation.action_type] = result
        process.status = "planning"
        self.save_process(process)

    def fail_operation(self, operation_id: str, error: str) -> None:
        operation = self.update_operation_status(operation_id, status="failed", error=error)
        process = self.get_process(operation.process_id)
        process.status = "planning"
        self.save_process(process)

    def list_operations(self, process_id: str) -> list[Operation]:
        process = self.get_process(process_id)
        return [self.get_operation(operation_id) for operation_id in process.operations]

    def find_existing_operation(
        self,
        process_id: str,
        action_type: ActionType,
        statuses: set[OperationStatus],
    ) -> Operation | None:
        for operation in self.list_operations(process_id):
            if operation.action_type == action_type and operation.status in statuses:
                return operation
        return None

    def build_agent_view(self, process_id: str):
        from app.action_registry import get_available_actions
        from app.schemas import AgentProcessView

        process = self.get_process(process_id)
        operations = self.list_operations(process_id)

        completed = [op.action_type for op in operations if op.status == "completed"]
        pending = [op.action_type for op in operations if op.status in {"scheduled", "running"}]
        failed = [op.action_type for op in operations if op.status == "failed"]

        return AgentProcessView(
            process_id=process.process_id,
            prompt=process.prompt,
            status=process.status,
            completed_actions=completed,
            pending_actions=pending,
            failed_actions=failed,
            available_actions=get_available_actions(process, operations),
            results=process.results,
        )

    @staticmethod
    def _process_key(process_id: str) -> str:
        return f"process:{process_id}"

    @staticmethod
    def _operation_key(operation_id: str) -> str:
        return f"operation:{operation_id}"


store = RedisStore()
