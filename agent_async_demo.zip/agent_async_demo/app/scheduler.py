from __future__ import annotations

from app.action_registry import get_available_actions
from app.queues import enqueue_operation
from app.schemas import ActionType, ScheduledOperation
from app.store import RedisStore, store


class ActionScheduler:
    def __init__(self, redis_store: RedisStore | None = None):
        self.store = redis_store or store

    def schedule(self, process_id: str, action_type: ActionType, reason: str) -> ScheduledOperation:
        existing = self.store.find_existing_operation(
            process_id=process_id,
            action_type=action_type,
            statuses={"scheduled", "running", "completed"},
        )
        if existing:
            return ScheduledOperation(
                operation_id=existing.operation_id,
                action_type=action_type,
                status="already_exists",
                message=f"A ação {action_type} já existe com status {existing.status}.",
            )

        process = self.store.get_process(process_id)
        operations = self.store.list_operations(process_id)
        available_actions = get_available_actions(process, operations)

        if action_type not in available_actions:
            raise ValueError(
                f"Ação {action_type} não permitida neste estado. "
                f"Ações disponíveis: {available_actions}"
            )

        operation = self.store.create_operation(process_id, action_type, reason)
        enqueue_operation(operation.operation_id, action_type)

        return ScheduledOperation(
            operation_id=operation.operation_id,
            action_type=operation.action_type,
            status="scheduled",
            message=f"Ação {action_type} agendada.",
        )


scheduler = ActionScheduler()
