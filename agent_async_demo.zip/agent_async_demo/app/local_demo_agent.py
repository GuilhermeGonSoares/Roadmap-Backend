from __future__ import annotations

from app.schemas import AgentDecision, AgentDeps, ActionType


def run_local_demo_agent(process_id: str, deps: AgentDeps) -> AgentDecision:
    """
    Agente determinístico apenas para testar o fluxo sem chave de LLM.

    Ele simula a mesma decisão esperada do agente real:
    processador_anexos -> consulta_bec -> consulta_legibilidade -> registra_dossie -> finished.
    """
    view = deps.store.build_agent_view(process_id)

    if "registra_dossie" in view.completed_actions:
        return AgentDecision(
            status="finished",
            selected_action=None,
            operation_id=None,
            reason="O dossiê já foi registrado. Processo finalizado.",
        )

    action_order: list[ActionType] = [
        "processador_anexos",
        "consulta_bec",
        "consulta_legibilidade",
        "registra_dossie",
    ]

    for action_type in action_order:
        if action_type in view.available_actions:
            scheduled = deps.scheduler.schedule(
                process_id=process_id,
                action_type=action_type,
                reason=f"Modo local: próxima ação disponível é {action_type}.",
            )
            return AgentDecision(
                status="scheduled_operation",
                selected_action=action_type,
                operation_id=scheduled.operation_id,
                reason=scheduled.message,
            )

    return AgentDecision(
        status="needs_human_review",
        selected_action=None,
        operation_id=None,
        reason="Nenhuma ação disponível e o processo ainda não foi finalizado.",
    )
