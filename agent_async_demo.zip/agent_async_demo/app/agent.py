from __future__ import annotations

from pydantic_ai import Agent, RunContext

from app.schemas import AgentDecision, AgentDeps, AgentProcessView, ScheduledOperation
from app.settings import settings

SYSTEM_PROMPT = """
Você é um agente orquestrador de processos internos.

Sua função é decidir a próxima ação de negócio com base no estado atual do processo.
Você NÃO executa processamento pesado diretamente. Quando precisar processar algo,
chame uma tool de solicitação, que apenas agenda uma operação assíncrona.

Fluxo desejado:
1. Se ainda não existe resultado de processador_anexos, solicite processador_anexos.
2. Se processador_anexos terminou e ainda não existe consulta_bec, solicite consulta_bec.
3. Se consulta_bec terminou e ainda não existe consulta_legibilidade, solicite consulta_legibilidade.
4. Se consulta_bec e consulta_legibilidade terminaram e ainda não existe registra_dossie,
   solicite registra_dossie.
5. Se registra_dossie terminou, finalize o processo.

Regras obrigatórias:
- Consulte o estado do processo antes de decidir.
- Agende no máximo uma operação por rodada.
- Depois de agendar uma operação, retorne status "scheduled_operation" e pare.
- Nunca solicite uma ação que já esteja pendente ou concluída.
- Se nenhuma ação segura estiver disponível, retorne "needs_human_review".
- Sua resposta final deve seguir o schema AgentDecision.
"""

orchestration_agent = Agent(
    settings.pydantic_ai_model,
    deps_type=AgentDeps,
    output_type=AgentDecision,
    system_prompt=SYSTEM_PROMPT,
)


@orchestration_agent.tool
def get_process_state(ctx: RunContext[AgentDeps]) -> AgentProcessView:
    """
    Retorna o estado atual do processo, incluindo ações concluídas,
    ações pendentes, ações com erro, resultados existentes e ações disponíveis.
    """
    return ctx.deps.store.build_agent_view(ctx.deps.process_id)


@orchestration_agent.tool
def request_processador_anexos(ctx: RunContext[AgentDeps], reason: str) -> ScheduledOperation:
    """
    Agenda o processamento de anexos.

    Use quando ainda não existir resultado de processador_anexos.
    Não use se essa ação já estiver pendente ou concluída.
    """
    return ctx.deps.scheduler.schedule(
        process_id=ctx.deps.process_id,
        action_type="processador_anexos",
        reason=reason,
    )


@orchestration_agent.tool
def request_consulta_bec(ctx: RunContext[AgentDeps], reason: str) -> ScheduledOperation:
    """
    Agenda a consulta BEC.

    Use quando o processamento de anexos já tiver sido concluído.
    Não use se consulta_bec já estiver pendente ou concluída.
    """
    return ctx.deps.scheduler.schedule(
        process_id=ctx.deps.process_id,
        action_type="consulta_bec",
        reason=reason,
    )


@orchestration_agent.tool
def request_consulta_legibilidade(ctx: RunContext[AgentDeps], reason: str) -> ScheduledOperation:
    """
    Agenda a consulta de legibilidade.

    Use quando consulta_bec já tiver sido concluída.
    Não use se consulta_legibilidade já estiver pendente ou concluída.
    """
    return ctx.deps.scheduler.schedule(
        process_id=ctx.deps.process_id,
        action_type="consulta_legibilidade",
        reason=reason,
    )


@orchestration_agent.tool
def request_registra_dossie(ctx: RunContext[AgentDeps], reason: str) -> ScheduledOperation:
    """
    Agenda o registro de dossiê.

    Use quando consulta_bec e consulta_legibilidade já tiverem sido concluídas.
    Não use se registra_dossie já estiver pendente ou concluída.
    """
    return ctx.deps.scheduler.schedule(
        process_id=ctx.deps.process_id,
        action_type="registra_dossie",
        reason=reason,
    )


def build_agent_prompt(process_id: str, trigger: str) -> str:
    return f"""
Analise o processo {process_id} e decida a próxima ação.

Gatilho desta rodada: {trigger}

Lembre-se:
- primeiro chame get_process_state;
- se precisar processar algo, chame exatamente uma tool de request_*;
- se agendar algo, retorne scheduled_operation;
- se tudo estiver concluído, retorne finished.
"""


def run_pydantic_agent(process_id: str, trigger: str, deps: AgentDeps) -> AgentDecision:
    result = orchestration_agent.run_sync(
        build_agent_prompt(process_id=process_id, trigger=trigger),
        deps=deps,
    )

    # Em versões recentes do Pydantic AI, o output fica em result.output.
    # Algumas versões antigas usavam result.data.
    output = getattr(result, "output", None) or getattr(result, "data")
    return AgentDecision.model_validate(output)
