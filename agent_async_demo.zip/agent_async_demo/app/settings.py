import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    pydantic_ai_model: str = os.getenv("PYDANTIC_AI_MODEL", "openai:gpt-4o-mini")
    use_local_demo_agent: bool = os.getenv("USE_LOCAL_DEMO_AGENT", "true").lower() == "true"
    max_agent_iterations: int = int(os.getenv("MAX_AGENT_ITERATIONS", "10"))


settings = Settings()
