from __future__ import annotations

from fastapi import FastAPI, HTTPException

from app.queues import enqueue_agent_planner
from app.schemas import ProcessCreateRequest
from app.store import store

app = FastAPI(title="Agent Async Orchestration Demo")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/processes")
def create_process(payload: ProcessCreateRequest):
    process = store.create_process(prompt=payload.prompt)
    job_id = enqueue_agent_planner(process.process_id, trigger="process_created")

    return {
        "process_id": process.process_id,
        "status": process.status,
        "agent_job_id": job_id,
    }


@app.get("/processes/{process_id}")
def get_process(process_id: str):
    try:
        process = store.get_process(process_id)
        operations = store.list_operations(process_id)
        return {
            **process.model_dump(),
            "operations_detail": [operation.model_dump() for operation in operations],
            "agent_view": store.build_agent_view(process_id).model_dump(),
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/processes/{process_id}/resume")
def resume_agent(process_id: str):
    try:
        store.get_process(process_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    job_id = enqueue_agent_planner(process_id, trigger="manual_resume")
    return {"process_id": process_id, "agent_job_id": job_id}
