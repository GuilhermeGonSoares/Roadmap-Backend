from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from pydantic import BaseModel, Field


ActionType = Literal[
    "processador_anexos",
    "consulta_bec",
    "consulta_legibilidade",
    "registra_dossie",
]

ProcessStatus = Literal[
    "received",
    "planning",
    "waiting_operation",
    "running_operation",
    "finished",
    "failed",
    "needs_human_review",
]

OperationStatus = Literal["scheduled", "running", "completed", "failed"]


class ProcessCreateRequest(BaseModel):
    prompt: str = Field(..., examples=["Analise os anexos, consulte BEC, verifique legibilidade e registre o dossiê."])


class Operation(BaseModel):
    operation_id: str
    process_id: str
    action_type: ActionType
    status: OperationStatus = "scheduled"
    reason: str
    result: dict[str, Any] | None = None
    error: str | None = None


class ProcessState(BaseModel):
    process_id: str
    prompt: str
    status: ProcessStatus = "received"
    agent_iterations: int = 0
    operations: list[str] = Field(default_factory=list)
    results: dict[str, dict[str, Any]] = Field(default_factory=dict)
    decisions: list[dict[str, Any]] = Field(default_factory=list)


class ScheduledOperation(BaseModel):
    operation_id: str
    action_type: ActionType
    status: Literal["scheduled", "already_exists"]
    message: str


class AgentDecision(BaseModel):
    status: Literal[
        "scheduled_operation",
        "finished",
        "needs_human_review",
        "failed",
    ]
    selected_action: ActionType | None = None
    operation_id: str | None = None
    reason: str


class AgentProcessView(BaseModel):
    process_id: str
    prompt: str
    status: ProcessStatus
    completed_actions: list[ActionType]
    pending_actions: list[ActionType]
    failed_actions: list[ActionType]
    available_actions: list[ActionType]
    results: dict[str, dict[str, Any]]


@dataclass
class AgentDeps:
    process_id: str
    store: Any
    scheduler: Any
