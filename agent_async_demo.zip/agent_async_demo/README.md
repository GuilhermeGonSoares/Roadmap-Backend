# Agent Async Orchestration Demo

Projeto mínimo para entender como estruturar um agente Pydantic AI que escolhe tools, mas não executa processamento pesado diretamente.

A ideia do fluxo é:

```text
Request HTTP
  -> cria process_id
  -> enfileira AgentPlannerJob
  -> agente decide próxima ação
  -> tool agenda operação assíncrona
  -> worker executa serviço/MCP fake
  -> resultado é salvo
  -> agente é chamado novamente
  -> repete até finalizar
```

## O que este projeto demonstra

- Como tirar o agente do `BackgroundTask`.
- Como o agente identifica tools por nome, descrição e schema.
- Como uma tool chamada pelo agente agenda uma operação em fila.
- Como workers executam as chamadas reais de processamento.
- Como reativar o agente após cada resultado.
- Como manter estado em Redis para sobreviver a processos separados.

## Estrutura

```text
app/
  main.py                 # FastAPI: cria/consulta processo
  agent.py                # Pydantic AI Agent + tools
  local_demo_agent.py     # modo local sem LLM
  scheduler.py            # traduz ação de negócio em operação na fila
  queues.py               # filas RQ
  jobs.py                 # jobs de agente e execução
  fake_mcp_services.py    # simula MCPs com sleep + resultado fake
  store.py                # estado do processo/operação em Redis
  action_registry.py      # ações disponíveis e pré-requisitos
  schemas.py              # modelos Pydantic
  settings.py             # env vars
```

## Rodar

```bash
docker compose up --build
```

Criar um processo:

```bash
curl -X POST http://localhost:8000/processes \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Analise os anexos, consulte BEC, verifique legibilidade e registre o dossiê."}'
```

Consultar o processo:

```bash
curl http://localhost:8000/processes/<process_id>
```

O processo deve passar por:

```text
processador_anexos
consulta_bec
consulta_legibilidade
registra_dossie
finished
```

## Modo local vs modo real

Por padrão, o `docker-compose.yml` usa:

```text
USE_LOCAL_DEMO_AGENT=true
```

Assim você consegue testar a arquitetura sem chave de LLM.

Para usar o agente real Pydantic AI:

```yaml
environment:
  USE_LOCAL_DEMO_AGENT: "false"
  PYDANTIC_AI_MODEL: openai:gpt-4o-mini
  OPENAI_API_KEY: sua_chave
```

## Onde entraria o MCP real?

Neste arquivo:

```text
app/fake_mcp_services.py
```

Hoje existe:

```python
call_fake_mcp_service(action_type, process_id)
```

Em produção você trocaria por algo como:

```python
mcp_client.call_tool("consulta_bec", {"process_id": process_id})
```

O agente não precisa saber se por baixo existe MCP, HTTP, SDK interno ou outro mecanismo. Ele só agenda ações de negócio.

## Ideia central

A tool do agente não faz isso:

```text
request_consulta_bec -> chama MCP e espera terminar
```

Ela faz isso:

```text
request_consulta_bec -> cria operation_id -> joga na fila -> retorna scheduled
```

O worker faz a chamada real depois:

```text
execute_operation_job -> chama MCP fake/real -> salva resultado -> reativa agente
```
